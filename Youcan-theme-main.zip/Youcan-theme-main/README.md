# Youcan-theme
a simple (Free) Youcan theme for your Store

## Installation

1 - download theme file: ( https://github.com/MrAbdelaziz/Youcan-theme/blob/main/theme.zip)

2 - import theme file (https://seller-area.youcan.shop/admin/theme)

 change DATA and  Save
 
3 -Edit CSS/javascript config (https://seller-area.youcan.shop/admin/settings/online#css-js)

Add this line to (Additional header code)
```html
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/MrAbdelaziz/Youcan-theme/style/header-style.css">
```

Add this to (Additional footer code)
```html

<!-- chat Widget -->
<div style="position: fixed;right: 0px;bottom: 0px;width:70px;margin-bottom: 0.5rem;margin-right: 0.5rem;">

    <img src="https://www.flaticon.com/svg/static/icons/svg/3381/3381917.svg"
        style="position: relative;top: -59px;position: absolute;">

    <a href="https://api.whatsapp.com/send?phone=+212666666666">
        <img src="https://image.flaticon.com/icons/svg/1383/1383269.svg"
            style="border: 1px solid black;padding: 9px;border-bottom: 0;position: relative;background-color: aquamarine; ">
    </a>

    <a href="http://">
        <img src="https://www.flaticon.com/svg/static/icons/svg/1383/1383264.svg"
            style="border: 1px solid black;padding: 10px;border-top: 0;background-color: dodgerblue;">
    </a>

</div>
<!-- end chat Widget -->


<!-- Popup -->

<div id="MrAbdelaziz_popup"
    class="FlexContainer-lh6d3k-0 ModalWindow__Window-sc-1rlc96w-0 epHMcu eapp-popup-layout-variation-modal-component eapp-popup-layout-variation-modal-component-enter-done"
    role="dialog" tabindex="-1" aria-modal="true" style="pointer-events: all;display:none;">
    <div class="ModalBackdrop__Backdrop-sc-873age-0 envSuS eapp-popup-modal-overlay-component eapp-popup-modal-overlay-component-transition-entered"
        style="background-color: rgba(17, 17, 17, 0.7);"></div>
    <div class="FlexItem-rdg44b-0 ModalContent__Content-sc-1lyzazn-0 bzgeF eapp-popup-layout-variation-modal-content-container eapp-popup-layout-variation-modal-content-container-transition-entered"
        role="document">
        <div class="FlexContainer-lh6d3k-0 dRKFRl eapp-popup-content-component">
            <div onclick="MrAbdelaziz_popup()"
                class="Button__Block-sc-1c0eo6i-0 bhCgZe ModalControl__Control-sc-1dl29es-0 cLmiHt jsx-2881417189 eapp-popup-control-close-component transition-exited"
                tabindex="0" role="button">
                <svg viewBox="0 0 10 10" class="eapp-popup-control-close-icon">
                    <path fill-rule="nonzero"
                        d="M6.414 5l3.293 3.293a1 1 0 0 1-1.414 1.414L5 6.414 1.707 9.707A1 1 0 1 1 .293 8.293L3.586 5 .293 1.707A1 1 0 0 1 1.707.293L5 3.586 8.293.293a1 1 0 0 1 1.414 1.414L6.414 5z">
                    </path>
                </svg>
            </div>
            <div class="FlexItem-rdg44b-0 jBExIs">
                <div class="FlexContainer-lh6d3k-0 jyfuVZ eapp-popup-content-main">
                    <div class="FlexItem-rdg44b-0 cDvFSS eapp-popup-content-outer"
                        style="background-image: url('https://files.elfsight.com/storage/4bc9e068-6999-4781-ad0c-ab83bceba5ea/12ac6acf-35fc-4e63-920c-2291e8b01768.jpeg');">
                        <div class="eapp-popup-content-outer-image-overlay"
                            style="background-color: rgba(17, 17, 17, 0.6);"></div>
                        <div class="eapp-popup-content-inner">
                            <div
                                class="eapp-popup-content-blocks-container-component eapp-popup-content-blocks-container-paddings-medium">
                                <div class="eapp-popup-content-blocks-container-item">
                                    <div
                                        class="FlexContainer-lh6d3k-0 fWQEQp eapp-popup-block-variation-image-component">
                                        <div class="FlexContainer-lh6d3k-0 enfMWB">
                                            <img src="https://files.elfsight.com/storage/4bc9e068-6999-4781-ad0c-ab83bceba5ea/84590d74-76f1-4519-8a17-553116fd9de7.png"
                                                alt="" class="jsx-3400482160 eapp-popup-block-variation-image-img" />
                                        </div>
                                    </div>
                                </div>
                                <div class="eapp-popup-content-blocks-container-item">
                                    <div class="jsx-651102099 eapp-popup-block-variation-spacing-component"></div>
                                </div>
                                <div class="eapp-popup-content-blocks-container-item">
                                    <div class="jsx-711716781 eapp-popup-block-variation-title-component"> عروض راس
                                        السنة!</div>
                                </div>
                                <div class="eapp-popup-content-blocks-container-item">
                                    <div class="jsx-952473858 eapp-popup-block-variation-title-component"> تخفيضات تصل
                                        الى 50%-</div>
                                </div>
                                <div class="eapp-popup-content-blocks-container-item">
                                    <div class="jsx-2715126705 eapp-popup-block-variation-text-component">
                                        <div class="jsx-2715126705 eapp-popup-block-variation-text-text">رقم القسيمة
                                            :<br /></div>
                                    </div>
                                </div>
                                <div class="eapp-popup-content-blocks-container-item">
                                    <div class="jsx-2749092036 eapp-popup-block-variation-coupon-component">
                                        <div class="Button__Block-sc-1c0eo6i-0 bhCgZe jsx-2749092036 eapp-popup-block-variation-coupon-area"
                                            tabindex="0" role="button">
                                            <div class="jsx-2749092036 eapp-popup-block-variation-coupon-tooltip">قم
                                                بنسخ الرمز</div>
                                            <div class="eapp-popup-block-variation-coupon-code">GET50</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="eapp-popup-content-blocks-container-item">
                                    <div class="eapp-popup-block-variation-button-component">
                                        <div></div>
                                        <a class="Button__Block-sc-1c0eo6i-0 bhCgZe jsx-3403832932 eapp-popup-button-component"
                                            tabindex="0" role="button" href="https://sahrawiya.com/collections">ابدأ
                                            التسوق</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Popup  || Coded By MrAbdelaziz -->

<script src="https://cdn.jsdelivr.net/gh/MrAbdelaziz/Youcan-theme/style/footer.js"></script>
```

